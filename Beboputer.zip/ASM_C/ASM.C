
/*
 *........	Bebop assembler.
 *
 *
 *..	Copyright (c) 1996 by Ed Smith.
 *	Written by Ed Smith.  Not derived from licensed software.
 *
 *	Permission is granted to Clive (Max) Maxfield and Alvin Brown to use
 *	this software for any purpose on any computer system, and to
 *	redistribute it freely, subject to the following restrictions:
 *
 *	1. The author is not responsible for the consequences of use of
 *		this software, no matter how awful, even if they arise
 *		from defects in it.
 *
 *	2. The origin of this software must not be misrepresented, either
 *		by explicit claim or by omission.
 *
 *	3. Altered versions must be plainly marked as such, and must not
 *		be misrepresented as being the original software.
 *
 *..		Modifications:
 *
 *		03-Jan-96  Ed Smith	Original.
 *              	19-Sep-96  Alvin Brown  Corrected ROLC and RORC op code
 *                                      Corrected JO op code D9 to E9
*     		21-Oct-96 Alvin Brown Corrected ROM file ext if address is <0x4000
 *		21-Oct-96 Alvin Brown Corrected the handling of comment lines by adding a \n 
*					when they are written to the list file.
 *	Microsoft compile instructions (this will create asm.dll and asm.lib):
 *		cl -c -Zp -DSTRICT -DWIN32 asm.c
 *	and link it as:
 *		link /DLL /EXPORT:parse asm.obj
 */
#include <ctype.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#ifdef WIN32
#include <windows.h>
#endif

/*
 *..		Defines.
 */
#define FALSE		0
#define TRUE		1
#define MAX_LABEL_LEN	8		/* max chars in a label		*/
#define MAX_LINE_LEN	255		/* max length of source line	*/
#define MAX_WORD_LEN	63		/* max chars in a word		*/
#define MAX_RESERVE_RUN	1024		/* max allocated values in a single */
					/* .byte/.2byte/.4byte directive*/
#define toupper(a)	(islower(a) ? ((a)-32) : (a))
					/* convert a char to upper case	*/
/*
 *		and the addressing modes.
 */
#define IMP		0		/* implied addressing mode	*/
#define IMM		1
#define BIG		2
#define ABS		4
#define INDX		8
#define IND		16
#define PREIND		32
#define POSTIND		64
/*
 *		and the operators.
 */
#define PLUS		1
#define MINUS		2
#define MULTIPLY	3
#define DIVIDE		4
#define AND		5
#define OR		6
#define XOR		7
#define NOT		8		/* one's complement		*/
/*
 *		and the error codes
 */
#define ERR_NONE			0	/* no error found	     */
#define ERR_BAD_STATEMENT		1	/* unknown statement	     */
#define ERR_MISSING_INTEGER_EXPR	2	/* missing expression	     */
#define ERR_MISSING_INTEGER_REF		3	/* missing integer ref	     */
#define ERR_MISSING_RB			4	/* missing right `]`	     */
#define ERR_MISSING_RP			5	/* missing right ')'	     */
#define ERR_NO_EXPR_REQ			6	/* no expression required    */
#define ERR_BAD_EXPR			7	/* bad expression	     */
#define ERR_DIVIDE_ZERO			8	/* divide by zero	     */
#define ERR_DUP_LABEL			9	/* duplicated label	     */
#define ERR_MISSING_ORG			10	/* missing org statement     */
#define ERR_MISSING_END			11	/* missing end statement     */
#define ERR_MISPLACED_ORG		12	/* misplaced org statement   */
#define ERR_MISPLACED_EQU		13	/* misplaced equ statement   */
#define ERR_EXTRA_STATEMENTS		14	/* statements after END      */
#define ERR_BYTE_VAL_TOO_LARGE		15	/* out of byte range	     */
#define ERR_WORD_VAL_TOO_LARGE		16	/* out of word range	     */
#define ERR_BAD_ADDR_MODE		17	/* bad addr mode for instr   */
#define ERR_LABEL_ON_ORG		18	/* org doesn't support label */
#define ERR_LABEL_TOO_LONG		19	/* more than 8 chars	     */
#define ERR_BAD_ORG			20	/* bad origin statement      */
#define ERR_ROM_OVERFLOW		21	/* rom overflows into ram    */
#define ERR_LABEL_FORWARD_REF		22	/* forward ref to a label    */
#define ERR_CANT_OPEN_INPUT_FILE	23
#define ERR_CANT_OPEN_LIST_FILE		24
#define ERR_CANT_OPEN_OUTPUT_FILE	25

/******************************************************************************/

/*
 *..		Declare structures.
 *
 *		a list of line numbers for a label.
 */
	typedef struct linelist {
		struct linelist *next;	/* next in line number list	*/
		int lineno;		/* actual line number in file	*/
		int defined;		/* definition line		*/
	} Linelist;
/*
 *		a label in a linked list of labels.
 */
	typedef struct label {
		struct label *next;	/* next label in list		*/
		char *name;		/* label name			*/
		int value;		/* label's value		*/
		int is_a_constant;	/* it's a constant label	*/
		Linelist *used;		/* line number used list	*/
	} Label;
/*
 *		the structure to hold details about an error.
 */
	typedef struct error {
		int lineno;		/* line number in file in error */
		int code;		/* error code, one of ERR_...	*/
		int start_col;		/* col number, 0=start of line  */
		int end_col;		/* 0=end column number		*/
		int offset;		/* offset in file to start of line */
	} Error;

	typedef struct instruction {
		char *name;	/* opcode name				 */
		int id;
		int modes;	/* allowed addressing modes		 */
		int opcodes[8];	/* imp,imm,big,abs,abs-x,ind,x-ind,ind-x */
	} Instruction;

/******************************************************************************/

/*
 *..		Declare static variables.
 *
 *		The linked list of labels.
 */
	static Label *label_list_head;
/*
 *		a variable controlling the forward referencing of labels. If
 *		set TRUE then labels may be forward referenced. They cannot be
 *		forward refernced during the second pass of the assembler nor
 *		when reading declarations.
 */
	static int may_forward_reference_labels;
/*
 *		processing this line in the file.
 */
	static int g_lineno = 0;	/* processing this line in file	*/
	static int g_offset = 0;	/* offset to start of this line */
	static int g_last_line_len = 0; /* num chars in last read line	*/
/*
 *		the instruction names, allowed index types and opcodes for
 *		each possible addressing mode. NOTE the instruction names
 *		MUST be in alphabetical order.
 */
	static Instruction instructions[] = {
		"ADD",	0,	IMM | ABS | INDX,
				'?', 0x10, '?', 0x11, 0x12, '?', '?', '?',
		"ADDC",	1,	IMM | ABS | INDX,
				'?', 0x18, '?', 0x19, 0x1A, '?', '?', '?',
		"AND",	2,	IMM | ABS | INDX,
				'?', 0x30, '?', 0x31, 0x32, '?', '?', '?',
		"BLDIV",5,	BIG | ABS,
				'?', '?', 0xF0, 0xF1, '?', '?', '?', '?',
		"BLDSP",3,	BIG | ABS,
				'?', '?', 0x50, 0x51, '?', '?', '?', '?',
		"BLDX",	4,	BIG | ABS,
				'?', '?', 0xA0, 0xA1, '?', '?', '?', '?',
		"BSTSP",6,	ABS,
				'?', '?', '?', 0x59, '?', '?', '?', '?',
		"BSTX",	7,	ABS,
				'?', '?', '?', 0xA9, '?', '?', '?', '?',
		"CLRIM",8,	IMP,
				0x09, '?', '?', '?', '?', '?', '?', '?',
		"CMPA", 9,	IMM | ABS | INDX,
				'?', 0x60, '?', 0x61, 0x62, '?', '?', '?',
		"DECA", 10,	IMP,
				0x81, '?', '?', '?', '?', '?', '?', '?',
		"DECX", 11,	IMP,
				0x83, '?', '?', '?', '?', '?', '?', '?',
		"HALT", 12,	IMP,
				0x01, '?', '?', '?', '?', '?', '?', '?',
		"INCA", 13,	IMP,
				0x80, '?', '?', '?', '?', '?', '?', '?',
		"INCX", 14,	IMP,
				0x82, '?', '?', '?', '?', '?', '?', '?',
		"JC",	15,	ABS,
				'?', '?', '?', 0xE1, '?', '?', '?', '?',
		"JMP",	23,	ABS | INDX | IND | PREIND | POSTIND,
				'?', '?', '?', 0xC1, 0xC2, 0xC3, 0xC4, 0xC5,
		"JN",	17,	ABS,
				'?', '?', '?', 0xD9, '?', '?', '?', '?',
		"JNC",	16,	ABS,
				'?', '?', '?', 0xE6, '?', '?', '?', '?',
		"JNN",	18,	ABS,
				'?', '?', '?', 0xDE, '?', '?', '?', '?',
		"JNO",	20,	ABS,
				'?', '?', '?', 0xEE, '?', '?', '?', '?',
		"JNZ",	22,	ABS,
				'?', '?', '?', 0xD6, '?', '?', '?', '?',
		"JO",	19,	ABS,
                                '?', '?', '?', 0xE9, '?', '?', '?', '?',
		"JSR",	24,	ABS | INDX | IND | PREIND | POSTIND,
				'?', '?', '?', 0xC9, 0xCA, 0xCB, 0xCC, 0xCD,
		"JZ",	21,	ABS,
				'?', '?', '?', 0xD1, '?', '?', '?', '?',
		"LDA",	25,	IMM | ABS | INDX | IND | PREIND | POSTIND,
				'?', 0x90, '?', 0x91, 0x92, 0x93, 0x94, 0x95,
		"NOP",	26,	IMP,
				0x00, '?', '?', '?', '?', '?', '?', '?',
		"OR",	27,	IMM | ABS | INDX,
				'?', 0x38, '?', 0x39, 0x3A, '?', '?', '?',
		"POPA", 28,	IMP,
				0xB0, '?', '?', '?', '?', '?', '?', '?',
		"POPSR",29,	IMP,
				0xB1, '?', '?', '?', '?', '?', '?', '?',
		"PUSHA",30,	IMP,
				0xB2, '?', '?', '?', '?', '?', '?', '?',
		"PUSHSR",31,	IMP,
				0xB3, '?', '?', '?', '?', '?', '?', '?',
                "ROLC", 32,     IMP,
				0x78, '?', '?', '?', '?', '?', '?', '?',
                "RORC", 33,     IMP,
				0x79, '?', '?', '?', '?', '?', '?', '?',
		"RTI",	34,	IMP,
				0xC7, '?', '?', '?', '?', '?', '?', '?',
		"RTS",	35,	IMP,
				0xCF, '?', '?', '?', '?', '?', '?', '?',
		"SETIM",36,	IMP,
				0x08, '?', '?', '?', '?', '?', '?', '?',
		"SHL",	37,	IMP,
				0x70, '?', '?', '?', '?', '?', '?', '?',
		"SHR",	38,	IMP,
				0x71, '?', '?', '?', '?', '?', '?', '?',
		"STA",	39,	ABS | INDX | IND | PREIND | POSTIND,
				'?', '?', '?', 0x99, 0x9A, 0x9B, 0x9C, 0x9D,
		"SUB",	40,	IMM | ABS | INDX,
				'?', 0x20, '?', 0x21, 0x22, '?', '?', '?',
		"SUBC",	41,	IMM | ABS | INDX,
				'?', 0x28, '?', 0x29, 0x2A, '?', '?', '?',
		"XOR",	42,	IMM | ABS | INDX,
				'?', 0x40, '?', 0x41, 0x42, '?', '?', '?',
		0,	0,	0,			/* terminator	*/
				'?', '?', '?', '?', '?', '?', '?', '?',
	};

/******************************************************************************/

/*
 *..		Local functions.
 */
#ifdef WIN32
	__declspec (dllexport) int FAR PASCAL parse(char *input_file_name,
						    int *lineno,
						    int *code,
						    int *start_col,
						    int *end_col,
						    int *offset);
#else
	int parse(char *input_file_name, int *lineno, int *code,
		  int *start_col, int *end_col, int *offset);
#endif
	int first_pass(FILE *input_file, int *start_addr, int *end_addr,
		       Error *error);
	int second_pass(FILE *input_file, FILE *list_file, FILE *output_file,
			Error *error);
	int is_origin(char **ps, int *pc, Error *error, FILE *list_file);
	int is_end(char **ps, FILE *list_file);
	int is_declaration(char **ps, int *pc, char *label, Error *error,
			   FILE *list_file);
	int is_reserve(char **ps, int *pc, int *byte_width, int *num,
		       int vals[], Error *error);
	int is_instruction(char **ps, int *pc, int *instruction,
			   int *integer_expr, int *mode, Error *error);
	int is_known_statement(char *ps);
	int is_label(char **ps, char *label);
	int is_label_plus_colon(char **ps, int pc, char *label, Error *error);
	int is_word(char **ps, char *word);
	int is_char(char **ps, char c);
	int is_integer_expr(char **ps, int *pc, int *value, Error *error);
	int is_integer_primary(char **ps, int *pc, int *value, Error *error);
	int is_unary_op(char **ps, int *op);
	int is_binary_op(char **ps, int *op);
	int is_integer_ref(char **ps, int *value, Error *error);
	int is_dec_literal(char **ps, int *value);
	int is_hex_literal(char **ps, int *value);
	int is_bin_literal(char **ps, int *value);
	int get_line(FILE *fp, FILE *list_file, char *line);
	Label *label_add(char *label_name, int value);
	Label *label_lookup(char *label_name);
	void label_used(Label *label, int defined, int lineno);
	void label_free(void);
	void *linklist_add(void **head, int size);
	int mode_to_index(int addr_mode);
	int is_a_byte_val(int val);
	int is_a_word_val(int val);
	static char *strupr(char *string);
	int strcmpan(char *compare, char *ref);
	void skip_white_space(char **p);
	void write_list_header(FILE *list_file, char *filename);
	void write_label_xref(FILE *list_file);
	void write_output_header(FILE *output_file, char *input_file_name,
				 int start_addr, int end_addr);
	void filename_split(char *file_spec, char **drive, char **dir,
			    char **body, char **ext);
	void filename_make(char *file_spec, char *drive, char *dir, char *body,
			   char *ext);
	void filename_change_extension(char *file_spec, char *req_ext);
	void err_set(Error *error, int code, int start_col, int end_col);
	void parse_init(Error *error);

/******************************************************************************/



#ifdef WIN32
__declspec (dllexport) int FAR PASCAL parse(char *input_file_name,
					    int *err_lineno,
					    int *err_code,
					    int *err_start_col,
					    int *err_end_col,
					    int *err_offset)
#else
int parse(char *input_file_name, int *err_lineno, int *err_code,
	  int *err_start_col, int *err_end_col, int *err_offset)
#endif
/*
 *........	To parse the assembler file 'input_file_name'. A list file and
 *		the assembler will be generated. Compiler operates in two
 *		passes, the first pass checks for syntax errors and determines
 *		the location of all labels so the the second pass can generate
 *		the assembler once the addresses of all the labels are known.
 *		Any error is returned in the 'err_...' variables. Returns TRUE
 *		if compilation was successful.
 */
{
	char list_file_name[256], output_file_name[256];
	int ok, start_addr, end_addr;
	Error error;
	FILE *input_file, *list_file, *output_file;

/*
 *		Initialize.
 */
	parse_init(&error);
	input_file = output_file = list_file = (FILE *)0;
	ok = FALSE;
/*
 *		Open input file.
 */
	input_file = fopen(input_file_name, "r");
	if(!input_file) { 
		err_set(&error, ERR_CANT_OPEN_INPUT_FILE, 0,0);
		goto exit;
	}
/*
 *		Do first pass.
 */
	ok = first_pass(input_file, &start_addr, &end_addr, &error);
/*
 *		Check validity of start and end addresses. If in ROM then end
 *		address may not flow into RAM.
 */
	if(ok)  {
		if(start_addr<0x1000 && end_addr>0x3fff) {
			err_set(&error, ERR_ROM_OVERFLOW, 0,0);
			goto exit;
		}
	}
/*
 *		Do second pass.
 */
	if(ok) {
		/* open list file. List file has a '.lst' extension. */
		strcpy(list_file_name, input_file_name);
		filename_change_extension(list_file_name, "lst");
		list_file = fopen(list_file_name, "w");
		if(!list_file) {
			fclose(input_file);
			err_set(&error, ERR_CANT_OPEN_LIST_FILE, 0,0);
			goto exit;
		}

		/* open output file, the extension is either ram or rom
		   depending upon the value of the .ORG statement. */
		strcpy(output_file_name, input_file_name);
		if((start_addr > 0x1000) &(start_addr < 0x4000))
			filename_change_extension(output_file_name, "rom");
		else 
			filename_change_extension(output_file_name, "ram");
		output_file = fopen(output_file_name, "w");
		if(!output_file) {
			fclose(input_file);
			fclose(list_file);
			err_set(&error, ERR_CANT_OPEN_OUTPUT_FILE, 0,0);
			goto exit;
		}

		/* write headers for the list and output files. */
		write_list_header(list_file, input_file_name);
		write_output_header(output_file, input_file_name,
				    start_addr, end_addr);

		/* generate the list file and assembled output file 	*/
		parse_init(&error);		/* reset parser		*/
		rewind(input_file);		/* rewind input file	*/
		ok = second_pass(input_file,list_file,output_file, &error);

		/* write label cross reference section to the list file */
		write_label_xref(list_file);
		/* and write terminator to output file */
		fprintf(output_file, "END OF DATA\n");
	}
/*
 *		Close all files.
 */
exit:	if(input_file)
		fclose(input_file);
	if(list_file)
		fclose(list_file);
	if(output_file)
		fclose(output_file);
/*
 *		Free all label storage.
 */
	label_free();
/*
 *		Remove output files if an error.
 */
	if(!ok) {
		remove(list_file_name);
		remove(output_file_name);
	}
	*err_lineno    = error.lineno;
	*err_code      = error.code;
	*err_start_col = error.start_col;
	*err_end_col   = error.end_col;
	*err_offset    = error.offset;
	return( error.lineno>0 ? FALSE : TRUE );
}



int first_pass(FILE *input_file, int *start_addr, int *end_addr, Error *error)
/*
 *........	To make the first pass across the input file. The start address
 *		(defined with the origin statement) and the end address are
 *		returned.  Returns TRUE if ok, else FALSE if some assembler
 *		errors found. First pass checks the syntax and determines the
 *		addresses of all labels - these are saved in a linked list of
 *		labels.
 */
{
	char *p;
	char label[MAX_LABEL_LEN+1];
	char line[MAX_LINE_LEN+1];
	int vals[MAX_RESERVE_RUN];
	int byte_width, inst, mode, num, org_label_found, val;
	int pc = 0;

/*
 *		Initialize.
 */
	error->lineno = error->code = error->start_col = error->end_col = 0;
	/* labels may not be forward referenced until we reach the reserve or
	   instruction statements. */
	may_forward_reference_labels = FALSE;
/*
 *..		Decode statements. Order of statements is:
 *			.EQU declaration statement (optional)
 *			.ORG origin statement
 *			reserve statements and/or instruction statements
 *			.END
 *
 *		First the optional declarations.
 */
	get_line(input_file, (FILE *)0, line); p = line;
	while(1) {
		if(is_label_plus_colon(&p, pc, label, error)) {
			if(is_declaration(&p, &pc, label, error, (FILE *)0)) {
				get_line(input_file, (FILE *)0, line); p = line;
			} else {
				break;
			}
		} else {
			break;
		}
	}
	if(error->code) {
		error->lineno = g_lineno;
		if(error->start_col)
			error->start_col = (char *)error->start_col - line;
		return(FALSE);
	}
	/* end of declarations reset pointer to start of line. */
	p = line;
/*
 *		Origin statement should be next. A Label is not permitted with
 *		this statement.
 */
	if(is_label(&p, label) && is_char(&p, ':'))
		org_label_found = TRUE;
	else
		org_label_found = FALSE;
	if(is_origin(&p, &pc, error, (FILE *)0)) {
		/* check validity of origin */
		if(pc < 0x1000) {
			err_set(error, ERR_BAD_ORG, 0,0);
			return(FALSE);
		}
		if(org_label_found) {
			err_set(error, ERR_LABEL_ON_ORG, 0,0);
			return(FALSE);
		}
		*start_addr = pc;
	} else if(!is_known_statement(p)) {
		err_set(error, ERR_BAD_STATEMENT, 0,0);
		return(FALSE);
	} else {
		err_set(error, ERR_MISSING_ORG, 0,0);
		return(FALSE);
	}
	get_line(input_file, (FILE *)0, line); p = line;
/*
 *		Then the reserve and instruction statements.  Labels may now be
 *		forward referenced.
 */
	may_forward_reference_labels = TRUE;
	while(1) {
		/* check for a label and check it's valid */
		is_label_plus_colon(&p, pc, label, error);
		if(error->code)
			break;
		if(is_instruction(&p, &pc, &inst, &val, &mode, error)) {
			get_line(input_file, (FILE *)0, line); p = line;
		} else if(is_reserve(&p, &pc, &byte_width, &num, vals, error)) {
			get_line(input_file, (FILE *)0, line); p = line;
		} else {
			break;
		}
	}
	if(error->code) {
		error->start_col = (char *)error->start_col - line;
		return(FALSE);
	} else if(*p && !is_known_statement(p)) {
		err_set(error, ERR_BAD_STATEMENT, 0,0);
		return(FALSE);
	}
/*
 *		Not a reserve or instruction statement - check for misplaced
 *		statements.
 */
	if(is_declaration(&p, &pc, label, error, (FILE *)0)) {
		err_set(error, ERR_MISPLACED_EQU, 0,0);
		return(FALSE);
	}
	if(is_origin(&p, &pc, error, (FILE *)0)) {
		err_set(error, ERR_MISPLACED_ORG, 0,0);
		return(FALSE);
	}
/*
 *		and finally the end statement.
 */
	if(is_end(&p, (FILE *)0)) {
		;
	} else if(*p && !is_known_statement(p)) {
		err_set(error, ERR_BAD_STATEMENT, 0,0);
		return(FALSE);
	} else {
		err_set(error, ERR_MISSING_END, 0,0);
		return(FALSE);
	}
/*
 *		make sure no more statements after the end statement.
 */
	if(get_line(input_file, (FILE *)0, line)) {
		err_set(error, ERR_EXTRA_STATEMENTS, 0,0);
		return(FALSE);
	}
/*
 *		Return end address - it will be one less than the current pc.
 */
	*end_addr = pc-1;
	return(TRUE);
}



int second_pass(FILE *input_file, FILE *list_file, FILE *output_file,
		Error *error)
/*
 *........	To perform the second pass across the input assembly file, this
 *		time we know the values of all the labels, so we'll output the
 *		assembly code to the output file. The syntax checking performed
 *		in the first pass is not required in the second.  The start and
 *		end addresses, which were determined in the first pass, are
 *		passed in.  Returns TRUE if source is output correctly.
 */
{
	char *p, *pi;
	char label[MAX_LABEL_LEN+1];
	char line[MAX_LINE_LEN+1];
	int vals[MAX_RESERVE_RUN];
	int byte_width, i, inst, label_found, mode, num, val, temp;
	int pc = 0, old_pc;

/*
 *		Initialize.
 */
	error->lineno = error->code = error->start_col = error->end_col = 0;
	/* labels may never be forward referenced during the second pass. */
	may_forward_reference_labels = FALSE;
/*
 *..		Decode statements. Order of statements is:
 *			.EQU declaration statement (optional)
 *			.ORG origin statement
 *			reserve statements and/or instruction statements
 *			.END
 *
 *		First the optional declarations.
 */
	get_line(input_file, list_file, line); p = line;
	while(is_label(&p, label) &&
	      is_char(&p, ':') &&
	      is_declaration(&p, &pc, label, error, list_file)) {
		get_line(input_file, list_file, line); p = line;
	}
	/* end of declarations section, reset to start of line. */
	p = line;
	is_origin(&p, &pc, error, list_file);
	get_line(input_file, list_file, line); p = line;
/*
 *		Then the reserve and instruction statements.
 */
	while(1) {
		if(is_label(&p, label) && is_char(&p, ':')) {
			label_found = TRUE;
		} else {
			p = line;		/* restore instruction */
			label_found = FALSE;
		}
		pi = p;
		old_pc = pc;
		if(is_instruction(&p, &pc, &inst, &val, &mode, error)) {

			/* write instruction to list file */
			if(list_file) {
				/* write line number and pc */
				fprintf(list_file, "%05d %04X ",
					g_lineno, old_pc);
				/* write opcode */
				temp = mode_to_index(mode);
				fprintf(list_file, "%02X ",
					instructions[inst].opcodes[temp]);
				/* write data bytes */
				if(mode == IMP) {
					fprintf(list_file, "       ");
				} else if(mode == IMM) {
					temp = val & 0xff;
					if(val < 0)
						temp |= 0x80;
					fprintf(list_file, "%02X     ", temp);
				} else {
					/* write top 8 bits */
					temp = (val >> 8) & 0xff;
					if(val < 0)
						temp |= 0x80;
					fprintf(list_file, "%02X ", temp);
					fprintf(list_file, "%02X  ",val & 0xff);
				}
				/* write label */
				if(label_found) {
					fprintf(list_file, "%s:", label);
					for(i=0; i<9-strlen(label); i++)
						fputc(' ', list_file);
				} else {
					fprintf(list_file, "          ");
				}
				/* write instruction name */
				fprintf(list_file, "%-7s",
					instructions[inst].name);
				/* write operands */
				skip_white_space(&pi);
				pi += strlen(instructions[inst].name);
				skip_white_space(&pi);
				fprintf(list_file, "%s\n", pi);
			}

			/* write to output file */
			if(output_file) {
				/* write opcode */
				temp = mode_to_index(mode);
				fprintf(output_file, "%3d\n",
					instructions[inst].opcodes[temp]);
				/* write data bytes */
				if(mode == IMP) {
					;
				} else if(mode == IMM) {
					temp = val & 0xff;
					if(val < 0)
						temp |= 0x80;
					fprintf(output_file, "%3d\n", temp);
				} else {
					/* write top 8 bits */
					temp = (val >> 8) & 0xff;
					if(val < 0)
						temp |= 0x80;
					fprintf(output_file, "%3d\n%3d\n",
						temp, val & 0xff);
				}
			}

		} else if(is_reserve(&p, &pc, &byte_width, &num, vals, error)) {

			/* write data to list file */
			if(list_file) {
				/* write line number and pc */
				fprintf(list_file, "%05d %04X ",
					g_lineno, old_pc);

				/* if bytes, write max of three on first
				   line */
				if(byte_width == 1) {
				    if(num >= 3)
					fprintf(list_file, "%02X %02X %02X  ",
						vals[0], vals[1], vals[2]);
				    else if(num == 2)
					fprintf(list_file, "%02X %02X     ",
						vals[0], vals[1]);
				    else
					fprintf(list_file, "%02X        ",
						vals[0]);
			        } else if(byte_width == 2) {
					temp = (vals[0] >> 8) & 0xff;
					if(vals[0] < 0)
						temp |= 0x80;
					fprintf(list_file, "%02X %02X     ",
						temp, vals[0] & 0xff);
				} else {
					temp = (vals[0] >> 24) & 0xff;
					if(vals[0] < 0)
						temp |= 0x80;
					fprintf(list_file, "%02X %02X     ",
						temp, (vals[0]>>16) & 0xff);
				}

				/* write label */
				if(label_found) {
					fprintf(list_file, "%s:", label);
					for(i=0; i<9-strlen(label); i++)
						fputc(' ', list_file);
				} else {
					fprintf(list_file, "          ");
				}
				/* write byte value */
				if(byte_width == 1)
					fprintf(list_file, ".BYTE  ");
				else if(byte_width == 2)
					fprintf(list_file, ".2BYTE ");
				else
					fprintf(list_file, ".4BYTE ");

				/* write data values from original source file*/
				skip_white_space(&pi);
				pi += 6;
				skip_white_space(&pi);
				fprintf(list_file, "%s\n", pi);

				/* write remainder of byte values on subsequent
				   lines. */
				if(byte_width == 1) {
				    if(num > 3) {
					for(i=3; i<num; i++) {
					    if(i>3 && i%3==0)
						fputc('\n', list_file);
					    if(i%3 == 0)
					       fprintf(list_file, "      %04X ",
						       old_pc + i);
					    fprintf(list_file, "%02X ",vals[i]);
				        }
					fputc('\n', list_file);
				    }
			        } else if(byte_width == 2) {
					for(i=1; i<num; i++) {
					    fprintf(list_file, "      %04X ",
						    old_pc + (2*(i-1)));
					    temp = (vals[i] >> 8) & 0xff;
					    if(vals[i] < 0)
						    temp |= 0x80;
					    fprintf(list_file, "%02X %02X\n",
						    temp, vals[i] & 0xff);
				    }
				} else {
				    /* last two bytes of first longword */
					fprintf(list_file, "      %04X ",
						old_pc + 2);
				    fprintf(list_file, "%02X %02X     ",
					    (vals[0]>>8) & 0xff,
					    vals[0] & 0xff);
				    for(i=1; i<num; i++) {
					    fprintf(list_file, "      %04X ",
						    old_pc + (4*(i-1)));
					    temp = (vals[i] >> 24) & 0xff;
					    if(vals[i] < 0)
						    temp |= 0x80;
					    fprintf(list_file, "%02X %02X\n",
						    temp, (vals[i]>>16) & 0xff);

					    fprintf(list_file, "      %04X ",
						    old_pc + 2 + (4*(i-1)));
					    fprintf(list_file, "%02X %02X\n",
						    (vals[i]>>8) & 0xff,
						    temp, vals[i] & 0xff);
				    }
				}
			}

			/* write to output file. Write one byte per line. */
			if(output_file) {
			    if(byte_width == 1) {
				for(i=0; i<num; i++)
					fprintf(output_file, "%3d\n", vals[i]);
			    } else if(byte_width == 2) {
				for(i=0; i<num; i++) {
					temp = (vals[i] >> 8) & 0xff;
					if(vals[i] < 0)
						temp |= 0x80;
					fprintf(output_file, "%3d\n%3d\n",
						temp, vals[i] & 0xff);
				}
			    } else {
				for(i=0; i<num; i++) {
					temp = (vals[i] >> 24) & 0xff;
					if(vals[i] < 0)
						temp |= 0x80;
					fprintf(output_file,
						"%3d\n%3d\n%3d\n%3d\n",
						temp,
						(vals[i]>>16) & 0xff,
						(vals[i]>>8) & 0xff,
						vals[i] & 0xff);
				}
			    }
		        }
		} else {
			break;
		}
		get_line(input_file, list_file, line); p = line;
	}
	if(error->code) {
		error->start_col = (char *)error->start_col - line;
		return(FALSE);
	}
/*
 *		and finally the end statement.
 */
	is_end(&p, list_file);
	return(TRUE);
}



/******************************************************************************/



int get_line(FILE *fp, FILE *list_file, char *line)
/*
 *........	To read the next non-blank line from the input file. Any
 *		comment lines, blank lines or trailing comments are removed.
 *		If the list file is specified, then any pure comment lines are
 *		written to the list file. Returns TRUE if a line is available.
 */
{
	char *p;

	/* read until we get a valid line */
 	while(fgets(line, MAX_LINE_LEN, fp)) {
		/* record global position in file to start of this line */
		g_offset += g_last_line_len;

		/* record data about current line */
		g_last_line_len = strlen(line);
		g_lineno++;
/*
 *			Strip trailing newline character.
 */
		line[g_last_line_len - 1] = '\0';
/*
 *			Is this a pure comment line (first char is a '#').
 */
		p = line;
		if(*p == '#') {
/*
 *				First char is a comment char so it's a pure
 *				comment line. Write to list file if requested.
 */
			if(list_file)
				fprintf(list_file, "%05d %s\n", g_lineno, line);
		} else {
			skip_white_space(&p);
			if(*p && *p!='#') {
/*
 *					Not a pure comment line and not a blank
 *					line.  Prune any comment from the end
 *					of the line.
 */
				p = strchr(line, '#');
				if(p)
					*p = '\0';
/*
 *					Convert to uppercase.
 */
				strupr(line);
				return(TRUE);
			} else {
/*
 *					A blank line or comment line that
 *					doesn't start in column one. write to
 *					list file if requested.
 */
				if(list_file)
					fprintf(list_file, "%05d\n", g_lineno);
			}
		}
	}
	*line = '\0';
	return(FALSE);				/* end-of-file		*/
}



/******************************************************************************/



int is_origin(char **ps, int *pc, Error *error, FILE *list_file)
/*
 *........	To determine if this statement is an origin statement, returns
 *		TRUE if it is. If an error is detected the contents of the
 *		error structure are filled out. 'list_file' is the file
 *		descriptor for the list file, if this is defined then we write
 *		origin statement to that file.
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];
	int val;

	if(is_word(&p, word) && strcmp(word, ".ORG")==0) {
		if(is_integer_ref(&p, &val, error)) {
			*pc = val;		/* set pc		*/
			*ps = p;
/*
 *				If a list file write statement.
 */
			if(list_file)
			   fprintf(list_file, "%05d                          .ORG   $%04X\n",
				   g_lineno, val);
			return(TRUE);
		} else {
			if(!error->code) 	/* err already assigned */
			    err_set(error, ERR_MISSING_INTEGER_EXPR, (int)p,0);
		}
	}
	return(FALSE);
}



int is_end(char **ps, FILE *list_file)
/*
 *........	To determine if this statement is an end directive, returns
 *		TRUE if it is. If 'list_file' is defined write the end
 *		statement out to this file.
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];

	if(is_word(&p, word) && strcmp(word, ".END")==0) {
		*ps = p;
/*
 *			If a list file write statement.
 */
		if(list_file) {
			fprintf(list_file, "%05d                           \n",
				g_lineno);
		}
		return(TRUE);
	}
	return(FALSE);
}



int is_declaration(char **ps, int *pc, char *label, Error *error,
		   FILE *list_file)
/*
 *........	To determine if this statement is a declaration directive. It
 *		returns TRUE if it is. If an error is detected the contents of
 *		the error structure are filled out. The label has already been
 *		saved in the label table, it's contents will be set. If the
 *		'list_file' is defined then we'll write the 
 */
{
	char *p = *ps;
	char *pd;
	char word[MAX_WORD_LEN+1];
	int i, val;
	Label *lp;

	if(is_word(&p, word) && strcmp(word, ".EQU")==0) {
		skip_white_space(&p); pd = p;	/* start of declaration */
		if(is_integer_expr(&p, pc, &val, error)) {
/*
 *				Valid declaration. Add label's value to label
 *				table. It's a constant label rather than an
 *				address label.
 */
			if(lp=label_lookup(label)) {
				lp->value = val;
				lp->is_a_constant = TRUE;
			}
			*ps = p;
/*
 *				If a list file write statement.
 */
			if(list_file) {
				fprintf(list_file, "%05d                %s:",
					g_lineno, label);
				for(i=0; i<9-strlen(label); i++)
					fputc(' ', list_file);
				fprintf(list_file, ".EQU   %s\n", pd);
			}
			return(TRUE);
		} else {
			if(!error->code) 	/* if unknown error	*/
			    err_set(error, ERR_MISSING_INTEGER_EXPR, (int)p,0);
		}
	}
	return(FALSE);
}



int is_reserve(char **ps, int *pc, int *byte_width, int *num, int byte_vals[],
	       Error *error)
/*
 *........	To determine if this statement is a reserve statement, returns
 *		TRUE if it is. If an error is detected the contents of the
 *		error structure are filled out. If 'list_file' is defined
 *		then we write the contents of the reserve statement 
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];
	int val, width = 0;

	if(!is_word(&p, word))
		return(FALSE);
	if(strcmp(word, ".BYTE") == 0) 	/* compare directive	*/
		width = 1;
	else if(strcmp(word, ".2BYTE") == 0)	/* compare directive	*/
		width = 2;
	else if(strcmp(word, ".4BYTE") == 0)	/* compare directive	*/
		width = 4;
	if(width > 0) {
		if(is_char(&p, '*') && is_integer_expr(&p, pc, &val, error)) {
			/* There are 'val' bytes to be reserved */
			*pc += val * width;	/* update pc		*/
			*ps = p;
			*byte_width = width;
			for((*num)=0; *num<val; (*num)++)
				byte_vals[*num] = 0;
			return(TRUE);
		} else if(is_integer_expr(&p, pc, &val, error)) {
			/* reserves a byte/word/long for each expression */
			/* check value within range */
			if(width==1 && !is_a_byte_val(val)) {
				err_set(error, ERR_BYTE_VAL_TOO_LARGE,
					(int)p, 0);
				return(FALSE);
			} else if(width==2 && !is_a_word_val(val)) {
				err_set(error, ERR_WORD_VAL_TOO_LARGE,
					(int)p, 0);
				return(FALSE);
			}
			*pc += width;

			*num = 0;
			byte_vals[(*num)++] = val;

			/* decoded subsequent ', expr' pairs */
			while(is_char(&p, ',')) {
				if(is_integer_expr(&p, pc, &val, error)) {
				    /* check value within range */
				    if(width==1 && !is_a_byte_val(val)) {
					err_set(error, ERR_BYTE_VAL_TOO_LARGE,
						(int)p, 0);
					return(FALSE);
				    } else if(width==2 && !is_a_word_val(val)) {
					err_set(error, ERR_WORD_VAL_TOO_LARGE,
						(int)p, 0);
					return(FALSE);
				    }
				    *pc += width;
				    byte_vals[(*num)++] = val;
				} else {
					err_set(error, ERR_MISSING_INTEGER_REF,
						(int)p, 0);
					return(FALSE);
				}
			}
			*ps = p;

			*byte_width = width;
			return(TRUE);
		} else if(!error->code) {
			/* reserves a single byte/word/long */
			*pc += width;
			*ps = p;

			*byte_width = width;
			*num = 1;
			byte_vals[0] = 0;
			return(TRUE);
		}
	}
	return(FALSE);
}



int is_instruction(char **ps, int *pc, int *instruction, int *integer_expr,
		   int *mode, Error *error)
/*
 *........	To determine if this statement is an instruction statement. It
 *		returns TRUE if it is. If an error is detected the contents of
 *		the error structure are filled out. The value of the integer
 *		expression (if it has one) will be returned. The instruction
 *		mode (implied, immediate. etc) is returned in 'mode'.
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];
	int id, cmp;

	skip_white_space(&p);
/*
 *		Get instruction name.
 */
	if(!is_word(&p, word))
		return(FALSE);
/*
 *		Is 'word' the name of a known instruction.
 */
	for(id=0; instructions[id].name; id++) {
		cmp = strcmp(instructions[id].name, word);
		if(cmp == 0)
			break;
		else if(cmp > 0) {
			id = -1;
			break;
		}
	}
	if(id >= 0) {				/* instruction id	*/
/*
 *			Valid instruction decoded, is it an implied instruction
 *			or does it have a following expression.
 */
	    if(instructions[id].modes) {	/* if not implied	*/
/*
 *			Is it an immediate mode instruction.
 */
		if(is_char(&p, '[')) {
		    char *pp;			/* remember pointer posn */
		    if(is_char(&p, '[')) {
			if(is_integer_expr(&p, pc, integer_expr, error))
			    ;
			else
			    error->code = ERR_MISSING_INTEGER_EXPR;
			/* remember pointer position */
			pp = p;
			if(is_char(&p, ',') && is_char(&p, 'X')) {
			    *mode = PREIND;
			    if(!is_char(&p, ']')) {
				if(!error->code)
				    error->code = ERR_MISSING_RB;
			    }
		        } else if(is_char(&p, ']') && 
				  is_char(&p, ',') &&
				  is_char(&p, 'X')) {
			    *mode = POSTIND;
		        } else {
			    *mode = IND;
			    /* ']' may have been stripped in above else if
			       clause, reset pointer */
			    p = pp;
			    if(!is_char(&p, ']'))
				error->code = ERR_MISSING_RB;
		        }
		    } else {
			if(is_integer_expr(&p, pc, integer_expr, error))
			    ;
			else if(!error->code)
			    error->code = ERR_MISSING_INTEGER_EXPR;
			if(is_char(&p, ',') && is_char(&p, 'X'))
			    *mode = INDX;
			else
			    *mode = ABS;
		    }
		    if(!is_char(&p, ']')) {
			if(!error->code)
			    error->code = ERR_MISSING_RB;
		    }
	        } else {
/*
 *			Immediate or big immediate mode instruction, get value
 *			of it's following expression.
 */
		    if(instructions[id].modes & BIG)
			    *mode = BIG;
		    else
			    *mode = IMM;
		    if(is_integer_expr(&p, pc, integer_expr, error))
			;
		    else if(!error->code)
			error->code = ERR_MISSING_INTEGER_EXPR;
	        }
		if(!error->code) {
/*
 *				Valid instruction and integer expression. Check
 *				instruction supports this mode
 */
			if(!(instructions[id].modes & *mode)){
				err_set(error, ERR_BAD_ADDR_MODE, 0,0);
				return(FALSE);
			}
/*
 *				Valid instruction and integer expression and
 *				mode - how many bytes wide is it.
 */
			*instruction = id;
			if(instructions[id].modes & BIG) {
				*pc += 3;
				if(!is_a_word_val(*integer_expr)) {
					err_set(error, ERR_WORD_VAL_TOO_LARGE,
						0, 0);
					return(FALSE);
				}
			} else if(*mode == IMM) {
				*pc += 2;
				if(!is_a_byte_val(*integer_expr)) {
					err_set(error, ERR_BYTE_VAL_TOO_LARGE,
						0,0);
					return(FALSE);
				}
			} else {
				*pc += 3;
				if(!is_a_word_val(*integer_expr)) {
					err_set(error, ERR_WORD_VAL_TOO_LARGE,
						0,0);
					return(FALSE);
				}
			}
			*ps = p;
			return(TRUE);
		} else {
			err_set(error, error->code, (int)p, 0);
		}
	    } else {
/*
 *			Implied instruction, check it has no arguments.
 */
		    if(!is_word(&p, word)) {
			    *instruction = id;
			    *mode = IMP;
			    *pc += 1;	/* one byte instruction */
			    *ps = p;
			    return(TRUE);
		    } else {
			    err_set(error, ERR_BAD_ADDR_MODE, (int)p, 0);
		    }
	    }
	}
	return(FALSE);
}



int is_known_statement(char *ps)
/*
 *........	To determine if the statement is a known statement type, this
 *		is used during error reporting. Returns TRUE if a known
 *		statement type.
 */
{
	char *p = ps;
	char label[MAX_LABEL_LEN+1];
	int pc = 0, inst, mode, val, byte_width, num;
	Error error;

	is_label_plus_colon(&p, pc, label, &error);
	if(is_declaration(&p, &pc, label, &error, (FILE *)0))
		return(TRUE);
	if(is_origin(&p, &pc, &error, (FILE *)0))
		return(TRUE);
	if(is_instruction(&p, &pc, &inst, &val, &mode, &error))
		return(TRUE);
	if(is_reserve(&p, &pc, &byte_width, &num, &val, &error))
		return(TRUE);
	if(is_end(&p, (FILE *)0))
		return(TRUE);
	return(FALSE);
}



int is_label(char **ps, char *label)
/*
 *........	To determine if the next token is a label. The syntax of a
 *		label is 'name'. Returns TRUE if a label and increments the
 *		string pointer 'ps'. Returns the label name in 'label'.
 */
{
	char *p = *ps;
	char *pl = label;

	skip_white_space(&p);
	if(*p=='_' || isalpha(*p)) {
		*pl++ = *p++;
		while(isalpha(*p) || isdigit(*p) || *p=='_')
			*pl++ = *p++;
		*pl = '\0';
		*ps = p;
		return(TRUE);
	}
	return(FALSE);
}



int is_label_plus_colon(char **ps, int pc, char *label, Error *error)
/*
 *........	To determine if the passed string is a label followed by a
 *		colon. The syntax of a label is 'name:'. Returns TRUE if a
 *		label and increments the string pointer 'ps'. Returns the label
 *		name in 'label'.
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];
	Label *lp;

	if(is_label(&p, word)) {
		if(is_char(&p, ':')) {
/*
 *				Label decoded. Has it been used before.
 */
			if(label_lookup(word)) {
				err_set(error, ERR_DUP_LABEL, 0,strlen(word));
				return(FALSE);
			}
/*
 *				Make a check on label length.
 */
			if(strlen(word) > MAX_LABEL_LEN) {
				err_set(error, ERR_LABEL_TOO_LONG,
					0,strlen(word));
				return(FALSE);
			}
/*
 *				Valid label, register it's address and line in
 *				source file in which it's used. If this is a
 *				label for a .EQU statement then it's value will
 *				be updated later in 'is_declaration()'.
 */
			strcpy(label, word);
			lp = label_add(label, pc);
			label_used(lp, TRUE, g_lineno);
			*ps = p;
			return(TRUE);
		}
	}
	return(FALSE);
}



int is_word(char **ps, char *word)
/*
 *........	Returns a TRUE result if the next non-white space string is a
 *		word. If it is the source line pointer 'ps' is incremented to
 *		point at the next character after 'c'.
 */
{
	char *p = *ps;
	int i;

	skip_white_space(&p);
	i = 0;
	while(*p && !isspace(*p)) {
		if(i < MAX_WORD_LEN)
			*word++ = *p++;
		i++;
	}
	*word = '\0';
	if(i > 0) {
		*ps = p;
		return(TRUE);
	}
	return(FALSE);
}



int is_char(char **ps, char c)
/*
 *........	Returns a TRUE result if the next non-white space character is
 *		the character 'c'. If it is the source line pointer 'ps' is
 *		incremented to point at the next character after 'c'.
 */
{
	char *p = *ps;

	skip_white_space(&p);
	if(*p == c) {			/* is next required character	*/
		*ps = p+1;
		return(TRUE);
	}
	return(FALSE);
}



int is_integer_expr(char **ps, int *pc, int *value, Error *error)
/*
 *........	Returns a TRUE result if the next tokens are an integer
 *		expression. If it is, the source line pointer 'ps' is
 *		incremented to point at the next character after the integer
 *		expression. The value of the integer expression is returned in
 *		'value'.
 *		<integer_expr> ::= [(] <integer_primary> 
 *				   {<binary_op><integer_primary>} [)]
 */
{
	char *p = *ps;
	int op, v1, v2;

	skip_white_space(&p);
	if(is_integer_primary(&p, pc, &v1, error)) {
		if(is_binary_op(&p, &op)) {
			if(is_integer_expr(&p, pc, &v2, error)) {
				switch(op) {
				    case PLUS:
					v1 += v2;
					break;
				    case MINUS:
					v1 -= v2;
					break;
				    case MULTIPLY:
					v1 *= v2;
					break;
				    case DIVIDE:
					if(v2 == 0) {
						err_set(error, ERR_DIVIDE_ZERO,
							(int)p, 0);
						return(FALSE);
					}
					v1 /= v2;
					break;
				    case AND:
					v1 &= v2;
					break;
				    case OR:
					v1 |= v2;
					break;
				    case XOR:
					v1 ^= v2;
					break;
				}
			} else {
				if(!error->code) {
					err_set(error, ERR_BAD_EXPR,
						(int)p, 0);
				}
				return(FALSE);
			}
			*value = v1;
			*ps = p;
			return(TRUE);
		} else {
			/* if not a binary operator following the number
			   then the only thing that can follow a number is
			   either nothing or ')' or ',' or ']'*/
			skip_white_space(&p);
			if(!(*p) || *p==')' || *p==',' || *p==']') {
				*value = v1;
				*ps = p;
				return(TRUE);
			} else {
				if(!error->code)
					err_set(error, ERR_BAD_EXPR, (int)p,0);
				return(FALSE);
			}
		}
	} else if(is_unary_op(&p, &op) &&
		  is_integer_expr(&p, pc, &v1, error)) {
		switch(op) {
		    case MINUS:
			v1 = - v1;
			break;
		    case NOT:
			v1 = ~ v1;		/* one's complement	*/
			break;
		}
		*value = v1;
		*ps = p;
		return(TRUE);
	} else if(is_char(&p, '(') &&
		  is_integer_expr(&p, pc, &v1, error)) {
		if(is_char(&p, ')')) {
			if(is_binary_op(&p, &op)) {
				if(is_integer_expr(&p, pc, &v2, error)) {
					switch(op) {
					    case PLUS:
						v1 += v2;
						break;
					    case MINUS:
						v1 -= v2;
						break;
					    case MULTIPLY:
						v1 *= v2;
						break;
					    case DIVIDE:
						if(v2 == 0) {
							err_set(error,
								ERR_DIVIDE_ZERO,
								(int)p,
								0);
							return(FALSE);
						}
						v1 /= v2;
						break;
					    case AND:
						v1 &= v2;
						break;
					    case OR:
						v1 |= v2;
						break;
					    case XOR:
						v1 ^= v2;
						break;
					}
				} else {
					if(!error->code) {
						err_set(error, ERR_BAD_EXPR,
							(int)p, 0);
					}
					return(FALSE);
				}
			}
			*value = v1;
			*ps = p;
			return(TRUE);
		} else {
			if(!error->code)
				err_set(error, ERR_MISSING_RP, (int)p, 0);
			return(FALSE);
		}
	}
	return(FALSE);
}



int is_integer_primary(char **ps, int *pc, int *value, Error *error)
/*
 *........	To determine the value of the integer primary expression.
 *
 *		<integer_primary> ::= <integer_ref>
 *				  ||= @
 */
{
	char *p = *ps;

	skip_white_space(&p);
	if(is_integer_ref(&p, value, error)) {
		*ps = p;
		return(TRUE);
	} else if(is_char(&p, '@')) {
		*value = *pc;
		*ps = p;
		return(TRUE);
	}
	return(FALSE);
}



int is_binary_op(char **ps, int *op)
/*
 *........	To determine if the next token is an operator. Returns TRUE if
 *		it is and the operator type.
 *			<binary_op> ::= + | - | * | / | & | ^ | '|'
 */
{
	char *p = *ps;

	skip_white_space(&p);
	switch(*p) {
	    case '+':
		*op = PLUS;
		*ps = p+1;
		return(TRUE);
	    case '-':
		*op = MINUS;
		*ps = p+1;
		return(TRUE);
	    case '*':
		*op = MULTIPLY;
		*ps = p+1;
		return(TRUE);
	    case '/':
		*op = DIVIDE;
		*ps = p+1;
		return(TRUE);
	    case '&':
		*op = AND;
		*ps = p+1;
		return(TRUE);
	    case '|':
		*op = OR;
		*ps = p+1;
		return(TRUE);
	    case '^':
		*op = XOR;
		*ps = p+1;
		return(TRUE);
	}
	return(FALSE);
}



int is_unary_op(char **ps, int *op)
/*
 *........	To determine if the next token is an operator. Returns TRUE if
 *		it is and the operator type.
 *			<unary_op> ::= - | !
 *		The next character after the unary op must be either '(',
 *		a digit or the first character of a label.
 */
{
	char *p = *ps;

	skip_white_space(&p);
	switch(*p) {
	    case '-':
		*op = MINUS;
		++p;
		if(*p=='(' || *p=='_' || isalnum(*p) || *p=='%' || *p=='$') {
			*ps = p;
			return(TRUE);
		}
		break;
	    case '!':
		*op = NOT;
		++p;
		if(*p=='(' || *p=='_' || isalnum(*p) || *p=='%' || *p=='$') {
			*ps = p;
			return(TRUE);
		}
		break;
	}
	return(FALSE);
}



int is_integer_ref(char **ps, int *value, Error *error)
/*
 *........	Returns a TRUE result if the next non-white space token is an
 *		integer reference. If it is, the source line pointer 'ps' is
 *		incremented to point at the next character after the integer
 *		reference. The integer reference is returned in 'value'.
 */
{
	char *p = *ps;
	char word[MAX_WORD_LEN+1];
	Label *lp;

	skip_white_space(&p);
	if(is_dec_literal(&p, value) ||
	   is_bin_literal(&p, value) ||
	   is_hex_literal(&p, value)) {
		*ps = p;
		return(TRUE);
	} else if(is_label(&p, word)) {
		lp = label_lookup(word);
		if(lp) {			/* if already defined	*/
			label_used(lp, FALSE, g_lineno);  /* used here	*/
			*value = lp->value;
		} else if(may_forward_reference_labels) {
			/* assume a forward reference to a label */
			*value = 1;
		} else {
			/* a forward reference to a label and we are not
			   permitted to do that */
			err_set(error, ERR_LABEL_FORWARD_REF, (int)*ps, 0);
			return(FALSE);
		}
		*ps = p;
		return(TRUE);
	}
	return(FALSE);
}



int is_dec_literal(char **ps, int *value)
/*
 *........	To return a TRUE result if the next token is a decimal literal.
 *		The value of the decimal token will be returned in 'value'.
 */
{
	char *p = *ps;

	if(isdigit(*p)) {
		*value = 0;
		while(*p && isdigit(*p)) {
			*value *= 10;
			*value += *p - '0';
			p++;
		}
		*ps = p;
		return(TRUE);
	}
	return(FALSE);
}



int is_hex_literal(char **ps, int *value)
/*
 *........	To return a TRUE result if the next token is a hex literal.
 *		The value of the hex token will be returned in 'value' as a
 *		decimal value.
 */
{
	char *p = *ps;

	if(is_char(&p, '$')) {
		if(isxdigit(*p)) {
			*value = 0;
			while(*p && isxdigit(*p)) {
				*value *= 16;
				if(isdigit(*p))
					*value += *p - '0';
				else
					*value += toupper(*p) - 'A' + 10;
				p++;
			}
			*ps = p;
			return(TRUE);
		}
	}
	return(FALSE);
}



int is_bin_literal(char **ps, int *value)
/*
 *........	To return a TRUE result if the next token is a binary literal.
 *		The value of the binary token will be returned in 'value' as a
 *		decimal value.
 */
{
	char *p = *ps;

	if(is_char(&p, '%')) {
		if(*p=='0' || *p=='1') {
			*value = 0;
			while(*p && (*p=='0' || *p=='1')) {
				*value *= 2;
				*value += *p - '0';
				p++;
			}
			*ps = p;
			return(TRUE);
		}
	}
	return(FALSE);
}



/******************************************************************************/



Label *label_add(char *label_name, int value)
/*
 *........	To add a label to the list of known labels. The name of the
 *		label is 'label_name', and it has a value of 'value'. If the
 *		label already exists, we just return the reference to the
 *		existing label.
 */
{
	Label *last, *next, *label;

/*
 *..		Find correct location in list for new entry.
 */
	last = (Label *)0;
	for(next=label_list_head; next; last=next,next=next->next) {
		if(strcmpan(label_name, next->name) < 0)
			break;
	}
/*
 *		It goes before 'next' and after 'last'. If last is null then
 *		it's inserted at the head of the queue.
 */
	if(!last) {
		label = (Label *)linklist_add((void **)&label_list_head,
					      sizeof(Label));
	} else {
		label = (Label *)linklist_add((void **)&last->next,
					      sizeof(Label));
	}
	if(label) {
		label->name = strdup(label_name);
		label->value = value;
	}
	return(label);
}



Label *label_lookup(char *label_name)
/*
 *........	To determine if the label 'label_name' is already known.
 */
{
	int cmp;
	Label *label;

	for(label=label_list_head; label; label=label->next) {
		cmp = strcmpan(label_name, label->name);
		if(cmp == 0)
			return(label);
		else if(cmp < 0)
			break;
	}
	return((Label *)0);
}



void label_used(Label *lp, int defined, int line)
/*
 *........	To register the fact that label 'lp' is used on line number
 *		'line' of this file and if 'defined' is TRUE then this is the
 *		location at which the label is defined. Label line numbers are
 *		added to list in ascending numerical order.
 */
{
	Linelist *last, *next, *llp;

/*
 *..		Find correct location in list for new entry. If entry is
 *		already in list then don't add it again.
 */
	last = (Linelist *)0;
	for(next=lp->used; next; last=next,next=next->next) {
		if(line == next->lineno)
			return;
		if(line < next->lineno)
			break;
	}
/*
 *		It goes before 'next' and after 'last'. If last is null then
 *		it's inserted at the head of the queue.
 */
	if(!last) {
		llp = (Linelist *)linklist_add((void **)&lp->used,
					       sizeof(Linelist));
	} else {
		llp = (Linelist *)linklist_add((void **)&last->next,
					       sizeof(Linelist));
	}
	if(llp) {
		llp->lineno = line;
		llp->defined = defined;
	}
}



void label_free(void)
/*
 *........	To free list list of known labels.
 */
{
	Label *lp, *lp_next;
	Linelist *llp, *llp_next;

	/* free all labels */
	for(lp=label_list_head; lp; lp=lp_next) {
		lp_next = lp->next;
		/* free label name */
		free(lp->name);
		/* free line number list */
		for(llp=lp->used; llp; llp=llp_next) {
			llp_next = llp->next;
			free(llp);
		}
		free(lp);
	}
	/* re-initialize label list */
	label_list_head = (Label *)0;
}



/******************************************************************************/



void *linklist_add(void **head, int size)
/*
 *........	This routine creates a new singly linked structure and returns
 *		a pointer to it. The routine will ensure that all the pointers
 *		are handled consistently and that the structure is empty. All
 *		structures have the 'next' data member at their head.
 *		Pointer is null if no room in memory for another structure.
 */
{
	void **cnew;

	cnew = (void **)malloc(size);		/* allocate memory	*/
	if(cnew) {
		memset((char *)cnew, 0, size);	/* initialize		*/
/*
 *			Link into head of singly linked list.
 */
		*cnew = *head;
		*head = (void *)cnew;
	}
	return((void *)cnew);
}



/******************************************************************************/



int mode_to_index(int addr_mode)
/*
 *........	To convert an addressing mode constant into an index into
 *		the opcodes in the instruction table.
 */
{
	switch(addr_mode) {
	    case IMP:
		return(0);
	    case IMM:
		return(1);
	    case BIG:
		return(2);
	    case ABS:
		return(3);
	    case INDX:
		return(4);
	    case IND:
		return(5);
	    case PREIND:
		return(6);
	    case POSTIND:
		return(7);
	}
}



int is_a_byte_val(int val)
/*
 *........	To check the passed value is a value that may be held in a
 *		byte. Returns TRUE if a byte value.
 */
{
	if(val>255 || val<-128)
		return(FALSE);
	return(TRUE);
}



int is_a_word_val(int val)
/*
 *........	To check the passed value is a value that may be held in a
 *		word. Returns TRUE if a word value.
 */
{
	if(val>65535 || val<-32768)
		return(FALSE);
	return(TRUE);
}



static char *strupr(char *string)
/*
 *........	Convert a string to upper case.
 */
{
	char *p = string;
	while(*p) {
		if(*p>='a' && *p <='z')
			*p -= 32;
		p++;
	}
	return(string);
}



int strcmpan(char *compare, char *ref)
/*
 *........	To compare two strings. This routine is similiar to strcmp()
 *		except that it compares two alphanumeric strings more
 *		intelligently. For instance if
 *			compare =	fred9
 *			ref	=	fred10
 *		then strcmp() would say that compare is greater than ref,
 *		however, this routine will return ref as greater than compare.
 *		This means that you can have prettier sorting orders ie
 *			ref1,ref2,ref3,ref4....ref9,ref10,ref11...etc
 *		They are sorted in their true order, not based upon the
 *		comparison of the two characters.
 *
 *..	Exit parameters:
 *		Returns 0 if the same, a positive number if compare > ref and a
 *		negative number if compare < ref.
 */
{
	char *pc = compare;			/* pntr into compare string */
	char *pr = ref; 			/* pntr into ref string     */
	int i,j;
	unsigned long lc, lr;

/*
 *		Pass through ref string until the end of one of the strings.
 */
	while(*pr && *pc) {
		if(isdigit(*pc) && isdigit(*pr)) {
/*
 *				Both strings contain numeric elements.
 *				Convert both of the numeric pieces to integer 
 *				values and then compare them. There will be a
 *				problem if the numeric bit is longer than nine
 *				chars (because the value is saved in a long) so
 *				just compare the first nine chars.
 */
			for(lc=0,i=0; *pc && isdigit(*pc) && i<9; pc++,i++) {
				lc = (lc*10) + (*pc-'0');
			}
			for(lr=0,j=0; *pr && isdigit(*pr) && i<9; pr++,j++) {
				lr = (lr*10) + (*pr-'0');
			}
			if(lc > lr)
				return(1);
			else if(lc < lr)
				return(-1);
			else if (i != j)
			    return(i-j);
		} else if(*pc == *pr) {		/* chars are the same	    */
			pc++; pr++;		/* point at next chars	    */
		} else {
/*
 *				Characters differ but they are not similiar
 *				strings. Return normal strcmp() lexicographic
 *				comparison value. Strings might be
 *					freda fredb
 */
			return(*pc - *pr);
		}
	}
/*
 *		End of one string. If a character still in compare string then
 *		it must be greater, if a character in ref string then it must
 *		be greater, else end of both strings so they must be the same.
 */
	if(*pc) 				/* more in compare string */
		return(1);
	else if(*pr)				/* more in ref string	  */
		return(-1);
	else					/* both the same	  */
		return(0);
}



void skip_white_space(char **ps)
/*
 *........	To skip white space in the character string pointed to by 'p'.
 *		We return a pointer to the first non-white space char.
 */
{
	char *p = *ps;
	while(*p && isspace(*p))		/* skip white space	*/
		p++;
	*ps = p;
}



/******************************************************************************/



void write_list_header(FILE *list_file, char *filename)
/*
 *........	To write a header for the list file.
 */
{
	char string[30];
	time_t curr_time;

	curr_time = time((time_t *)0);
	strcpy(string, asctime(localtime(&curr_time)));
	string[strlen(string)-1] = '\0';	/* remove newline */

	fprintf(list_file, "BEBOPUTER LIST FILE Version 1.0.0.0\nGENERATED BY BEBOPUTER ASSEMBLER Version 1.0.0.0 (%s)\nSOURCE WAS \"%s\"\n\nLINE  ADDR   DATA      LABEL   OPCODE OPERAND\n----- ---- --------  --------- ------ -------\n",
		&string[4], filename);
}



void write_label_xref(FILE *list_file)
/*
 *........	To write the label cross reference section to the list file.
 *		Written as two sections, constants and address labels.
 */
{
	int i;
	Label *lp;
	Linelist *llp;

/*
 *		First the constant labels.
 */
	fprintf(list_file, "\n\n\nCONSTANT LABELS CROSS-REFERENCE\n\n  NAME     VALUE   LINE NUMBERS WHERE USED (* INDICATES DECLARATION)\n-------- --------- ---------------------------------------------------\n");
	for(lp=label_list_head; lp; lp=lp->next) {
		if(lp->is_a_constant) {
			fprintf(list_file, "%-8s %08X  ", lp->name, lp->value);
			i = 0;
			for(llp=lp->used; llp; llp=llp->next) {
				/* write seven to a line */
				if(++i == 8) {
					fprintf(list_file, "\n                   ");
					i = 1;
				}
				fprintf(list_file, "%05d%s",
					llp->lineno,
					llp->defined ? "* " : "  ");
			}
			fputc('\n', list_file);
		}
	}
/*
 *		Then the address labels.
 */
	fprintf(list_file, "\n\n\nADDRESS LABELS CROSS-REFERENCE\n\n  NAME     VALUE   LINE NUMBERS WHERE USED (* INDICATES DECLARATION)\n-------- --------- ---------------------------------------------------\n");
	for(lp=label_list_head; lp; lp=lp->next) {
		if(!lp->is_a_constant) {
			fprintf(list_file, "%-8s ....%04X  ", lp->name, lp->value);
			i = 0;
			for(llp=lp->used; llp; llp=llp->next) {
				/* write seven to a line */
				if(++i == 8) {
					fprintf(list_file, "\n                   ");
					i = 1;
				}
				fprintf(list_file, "%05d%s",
					llp->lineno,
					llp->defined ? "* " : "  ");
			}
			fputc('\n', list_file);
		}
	}
}



void write_output_header(FILE *output_file, char *input_file_name,
			 int start_addr, int end_addr)
/*
 *........	To generate a header for the output file.
 */
{
	char string[30];
	time_t curr_time;

	curr_time = time((time_t *)0);
	strcpy(string, asctime(localtime(&curr_time)));
	string[strlen(string)-1] = '\0';	/* remove newline */

	/* is it a ram or rom file */
	if(start_addr < 0x4000)
		fprintf(output_file, "BEBOPUTER ROM ");
	else
		fprintf(output_file, "BEBOPUTER RAM ");
	fprintf(output_file, "FILE Version 1.0.0.0\n%d\n%d\n%s\nGENERATED BY BEBOPUTER ASSEMBLER Version 1.0.0.0 (%s)\nSTART OF DATA\n",
		start_addr, end_addr, input_file_name, &string[4]);
}



/******************************************************************************/

#define MSDOS		1		/* configure code for MSDOS 	*/
/*
 *		Filename lengths in characters
 */
#define EXPANDED_FILESPEC_LEN	255		/* characters		*/
/*
 *		Define the filename separator characters as a function of the
 *		system
 */
#ifdef MSDOS
#define DRIVE_SEP	':'
#define DIR_SEP 	'\\'
#define EXT_SEP 	'.'
#endif
#ifdef UNIX
#define DRIVE_SEP	':'
#define DIR_SEP 	'/'
#define EXT_SEP 	'.'
#endif



void filename_split(char *file_spec, char **drive, char **dir, char **body,
		    char **ext)
/*
 *........	This routine decomposes a passed file specification into its
 *		four component parts - the directory spec, the body of the
 *		file name and the filename extension. We split the filename up
 *		by placing nulls at position of the seperator between the
 *		directory and the file body and at the position of the seperator
 *		between the file body and the extension.
 *		The user passes pointers to pointers which will point at the
 *		location where each decomposed name part commences.
 *		Routine uses the conditional compilation flags to determine
 *		how to decompose the filename. It is of course a function of the
 *		operating system.
 *		One or more of the returned components in the filespec may be
 *		empty in which case the pointer for that part will be null.
 *		As an example consider the filespec
 *			a:\ed\test\gpua.asm
 *			'drive' will point at the string        'a'
 *			'dir' will point at the string          '\ed\test'
 *			'body' will point at the string         'gpua'
 *			'ext' will point at the string          'asm'
 */
{
	char *p, *pp;
#ifdef MSDOS
	static char *root_dir_spec = "\\";
#endif
#ifdef UNIX
	static char *root_dir_spec = "/";
#endif

/*
 *..		Initialise
 */
	*drive = *dir = *body = *ext = (char *)0;
	pp = file_spec;
/*
 *..		Handle operating system exceptions.
 */
#ifdef MSDOS
	if(strcmp(file_spec,".")==0 || strcmp(file_spec,"..")==0) {
		*dir = file_spec;
		return;
	}
#endif
#ifdef UNIX
	if(strcmp(file_spec,".")==0 || strcmp(file_spec,"..")==0) {
		*dir = file_spec;
		return;
	}
#endif
/*
 *..		Locate any leading drive spec from the file_spec.
 */
#ifdef MSDOS
	p = strrchr(pp,DRIVE_SEP);		/* find last occurance of */
#endif
#ifdef UNIX
	p = (char *)0;				/* no drive		*/
#endif
/*
 *		Was a drive spec detected.
 */
	if(p != (char *)0) {
/*
 *			Place eos at position of drive seperator and make
 *			'drive' point at drive name.
 */
		*p = '\0';
		*drive = pp;
		pp = p+1;			/* point at dir name	*/
	}
/*
 *..		Locate any leading path spec from the file_spec.
 */
	p = strrchr(pp,DIR_SEP);		/* find last occurance of */
/*
 *		Was a directory spec detected.
 */
	if(p != (char *)0) {
/*
 *			Place eos at position of directory seperator and make
 *			'dir' point at directory name. If a root directory,
 *			ensure spec is correct.
 */
		*p = '\0';
		if(*pp == '\0')                 /* if root directory    */
			*dir = root_dir_spec;
		else
			*dir = pp;
		pp = p+1;			/* point at file body	*/
	}
/*
 *..		'pp' points at first char in file body name. Search for any
 *		extension.
 */
	p = strrchr(pp,EXT_SEP);		/* position of dot	*/
	if(p != (char *)0) {
/*
 *			Place eos at position of extension seperator and make
 *			'ext' point at start of extension.
 */
		*p = '\0';
		*ext = p+1;
	}
	else
		p = pp + strlen(pp);
/*
 *		The file body starts at 'pp' and ends at 'p-1'. If no characters
 *		in body then empty bodyname.
 */
	if(p > pp)
		*body = pp;
/*
 *		All four file spec parts have been split.
 */
}



void filename_make(char *file_spec, char *drive, char *dir, char *body,
		   char *ext)
/*
 *........	To compose a complete file specification from all the 
 *		individual parts. Its is assumed that 'file_spec' is large 
 *		enough to hold the result. One or more of these parts may be 
 *		empty ( ie a null pointer ).
 */
{
	char *p = file_spec;
	int len;

/*
 *      	Ensure that we don't overflow 'file_spec'. (Not precisely 
 *		correct, since there may not be one or more *_SEP added to the 
 *		string)
 */
	if ((drive ? strlen(drive) : 0) +
	    (dir   ? strlen(dir)   : 0) +
	    (body  ? strlen(body)  : 0) +
	    (ext   ? strlen(ext)   : 0) + 3 >  EXPANDED_FILESPEC_LEN) {
		*p='\0';
		return;
	}
/*
 *..		Assemble filename.
 */
	if(drive!=(char *)0 && *drive!='\0') {
		len = strlen(drive);
		strncpy(p,drive, len);		/* drive		*/
		p += len;
		if(*(p-1) != DRIVE_SEP)
			*p++ = DRIVE_SEP;	/* add drive sep	*/
	}
	if(dir!=(char *)0 && *dir!='\0') {
		len = strlen(dir);
		strncpy(p,dir, len);		/* directory		*/
		p += len;
		if(*(p-1) != DIR_SEP &&
		   *(p-1) != DRIVE_SEP)
			*p++ = DIR_SEP; 	/* add dir sep		*/
	}
	if(body != (char *)0) {
		len = strlen(body);
		strncpy(p,body, len);		/* filename		*/
		p += len;
	}
	if(ext!=(char *)0 && *ext!='\0') {
		if(*ext == EXT_SEP)
		    ext++;			/* skip leading '.'	*/
		len = strlen(ext);
		*p++ = EXT_SEP; 		/* add extension	*/
		strncpy(p,ext, len);
		p += len;
	}
	*p = '\0';
}



void filename_change_extension(char *file_spec, char *req_ext)
/*
 *........	To ensure that the file specification 'file-spec' has the
 *		extension 'req_ext'.
 */
{
	char *drive, *dir, *body, *ext;

	filename_split(file_spec,&drive,&dir,&body,&ext);
	filename_make(file_spec,drive,dir,body,req_ext);
}



/******************************************************************************/



void err_set(Error *error, int code, int start_col, int end_col)
/*
 *........	To populate the error structure.
 */
{
	error->lineno 	 = g_lineno;
	error->code      = code;
	error->start_col = start_col;
	error->end_col   = end_col;
	error->offset	 = g_offset;
}



void parse_init(Error *error)
/*
 *........	To initialize all static variables and the error structure.
 */
{
	g_lineno = 0;				/* reset line number	*/
	g_offset = 0;				/* reset offset		*/
	g_last_line_len = 0;			/* reset last line len	*/
	err_set(error, ERR_NONE, 0,0);
}
